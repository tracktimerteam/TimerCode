/** \file
 *  \brief Runs the unit test on MSVC.
 */

#include "stdafx.h"
#include "unitTestRunner.h"
