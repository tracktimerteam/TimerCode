/*
 * "Copyright (c) 2008 Robert B. Reese, Bryan A. Jones, J. W. Bruce ("AUTHORS")"
 * All rights reserved.
 * (R. Reese, reese_AT_ece.msstate.edu, Mississippi State University)
 * (B. A. Jones, bjones_AT_ece.msstate.edu, Mississippi State University)
 * (J. W. Bruce, jwbruce_AT_ece.msstate.edu, Mississippi State University)
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the authors appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE "AUTHORS" BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE "AUTHORS"
 * HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE "AUTHORS" SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE "AUTHORS" HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Please maintain this header in its entirety when copying/modifying
 * these files.
 *
 *
 */



// Documentation for this file. If the \file tag isn't present,
// this file won't be documented.
/** \file
 *  Configure and possibly switch the processor clock to the
 *  desired frequency, based on selections made in
 *  pic24_clockfreq.h. Each entry in the \ref CLOCK_CONFIG
 *  table should have a corresponding block of code in this
 *  file to configure the clock. Typical code structure is:
 *  \code
 * #if IS_CLOCK_CONFIG(clock_config_value)
 * void configClock(void) {
 *   ... code to configure this clock ...
 *   // Typically, after setup code above, swtich to
 *   // the newly configured oscillator.
 *   switchClock(OSC_SEL_BITS);
 * }
 * #endif
 * \endcode
 *
 * Notes: is some modes, the configuration bit setting suggest
 * that a clock switch unnecessary. For example, FNOSC_PRI
 * or FNOSC_FRC should require no clock switching. However, if
 * this was run from a bootloader, the config bits may be set
 * by the bootloader, so a switch is still performed.
 * Likewise, in the PIC24H modes that use the PLL, the bootloader
 * could be using the PLL. In this can, PLL settings can't be
 * changed. So, the code switches to the FRC, changes PLL bits
 * (when it's guaranteed to be safe), the switch back to the PLL.
 */

#include "pic24_all.h"

void switchClock(uint8 u8_source) {
  // Create a union that mirrors the OSCCON structure
  // with all its bit names but is also byte-accessable.
  OSCCONBITS OSCCONBITS_copy;

  // Switch clock to use new choice specified by u8_choice.
  // Valid values are 0-7.
  // 1. Disable interrupts per 7.11.2 FRM rev B under
  //    "A recommended code sequence for a clock switch
  //     includes the following:" heading.
  //    Assumes there are no priority 7 interrupts enabled.
  asm("DISI #0x3FFF"); // Disable interrupts for a long time
  // 2. Switch to the PLL. Use compiler built-ins to unlock
  //    clock switch registers. See 7.11.1 of the FRM rev B.
  OSCCONBITS_copy = OSCCONbits;      // Copy OSCCON bits
  OSCCONBITS_copy.NOSC = u8_source;  // Select new clock source
  OSCCONBITS_copy.OSWEN = 1;         // Request clock switch
  // First write high byte, containing new clock source NOSC
  __builtin_write_OSCCONH(BITS2BYTEH(OSCCONBITS_copy));
  // Then write low byte, requesting clock switch with OSWEN
  __builtin_write_OSCCONL(BITS2BYTEL(OSCCONBITS_copy));
  asm("DISI #0");     // Re-enable them at the next instruction

#ifndef SIM
  // 3. Wait for switch to complete.
  //    Note that oscillator switching is not supported by
  //    the simulator, causing the statements below to
  //    run forever.
  while (_OSWEN == 1);

  // 4. Wait for the PLL to lock if using the PLL.
  if ( (u8_source == GET_OSC_SEL_BITS(FNOSC_FRCPLL)) ||
       (u8_source == GET_OSC_SEL_BITS(FNOSC_PRIPLL)) )
    while (_LOCK == 0);
#endif
}

#if IS_CLOCK_CONFIG(SIM_CLOCK)
#warning Clock configured for simulation, FCY = 1 Mhz
// Nothing to do! Simulator clock not set by OSCCON,
// but instead in the Debugger | Settings, Osc/Trace
// dialog box. It should be 2 MHz there, since that's
// Fosc = 2*Fcy. At 1 MHz, simulation speed seems fast
// enough to execute a reasonable amount of code. Also,
// at a 64K line trace buffer, we can see 64 ms of
// execution, which is plenty to see 20 ms servo pulses.
void configClock(void) { }
#endif


#if IS_CLOCK_CONFIG(FRCPLL_FCY16MHz)
#warning Clock configured for FRCPLL, FCY = 16 MHz
void configClock(void) {
  // To be safe: if this was run by a bootloader that chose FRCPLL mode,
  // then we can't change the bits below. To do so, first switch to FRC,
  // change bits, then switch back to FRCPLL.
  switchClock(GET_OSC_SEL_BITS(FNOSC_FRC));
  // Ensure that the FRC postscaler is at '1' and not its reset default of '2' (PIC24F family)
  _RCDIV = 0;
  switchClock(OSC_SEL_BITS);
}
#endif

#if IS_CLOCK_CONFIG(PRIPLL_8MHzCrystal_16MHzFCY)
#warning Clock configured for PRIPLL using a 8.0 Mhz primary oscillator, FCY = 16 MHz
void configClock(void) {
  // To be safe: if this was run by a bootloader that chose FRCPLL mode,
  // then we can't change the bits below. To do so, first switch to FRC,
  // change bits, then switch back to FRCPLL.
  switchClock(GET_OSC_SEL_BITS(FNOSC_FRC));
  // Ensure that the FRC postscaler is at '1' and not its reset default of '2' (PIC24F family)
  _RCDIV = 0;
  switchClock(OSC_SEL_BITS);
}
#endif


#if IS_CLOCK_CONFIG(FRC_FCY4MHz)
#warning Clock configured for FRC, FCY = 4 MHz.
#warning Baud rates of 19200 or lower recommended for this clock choice.
void configClock(void) {
  // Ensure that the FRC postscaler is at '1' and not its reset default of '2' (PIC24F family)
  _RCDIV = 0;
  switchClock(OSC_SEL_BITS);
}
#endif


#if IS_CLOCK_CONFIG(PRI_NO_PLL_7372KHzCrystal)
#warning Clock configured for the primary oscillator, no PLL
void configClock(void) {
  switchClock(OSC_SEL_BITS);
}
#endif

#if IS_CLOCK_CONFIG(PRI_NO_PLL_14745KHzCrystal)
#warning Clock configured for the primary oscillator, no PLL
void configClock(void) {
  switchClock(OSC_SEL_BITS);
}
#endif


#if IS_CLOCK_CONFIG(FRC_FCY3685KHz)
#warning Clock configured for FRC, FCY = 3.685 MHz
#warning Baud rates of 9600 or lower recommended for this clock choice.
void configClock(void) {
  switchClock(OSC_SEL_BITS);
  // Choose no tuning on FRC to get 7.37 MHz nominal FOSC.
  // Do after clock switch in case FRCPLL was in use, since
  // that would alter PLL input frequency. (Might be OK, but
  // this is perhaps safer.)
  _TUN = 0;
}
#endif


#if IS_CLOCK_CONFIG(FRCPLL_FCY40MHz)
#warning Clock configured for FRCPLL, FCY = 40 MHz
void configClock(void) {
  // To be safe: if this was run by a bootloader that chose FRCPLL mode,
  // then we can't change the bits below. To do so, first switch to FRC,
  // change bits, then switch back to FRCPLL.
  switchClock(GET_OSC_SEL_BITS(FNOSC_FRC));
  //settings for Cycle time = 40 MHz, internal oscillator with PLL
  // Tune the internal oscialltor to 6.85 MHz. Each unit
  // in the register below = 0.375% of the 7.37 MHz
  // nominal frequency in 2's complement per register 7-6
  // in section 7.4 of the FRM rev B. So:
  // Sanity check: -32*0.375% = -12% -> 6.4856 MHz per data sheet.
  //               +30*0.375% = 11.25% -> 8.1991 Mhz not 8.23 MHz
  //                                      given in the data sheet!
  //      However, +31*0.375% = 11.625% -> 8.2268 MHz, so the above
  //      is a typo. This error has been reported to Microchip and
  //      confirmed. It should be fixed in next rev of data sheet.
  // Another concern: since the clock is +/- 2%, we could end
  // up with a > 8.0 MHz processor clock! At 8 MHz, this would
  // be 8.16 MHz, so the processor would run at 81.6 MHz.
  // Ignore this for now; probably, the chip will still run.

  _TUN = -19;  // Correct setting assuming the RC oscillator is exactly 7.37MHz.
  // It may need to be tweaked however. Use the echo.c program, and a baud rate
  // of 115,200 and increase/decrease TUN until you get no framing errors

  // Choose PLL factors: Fref after first prescale must be
  // between 0.8 and 8.0 MHz. Choose a prescale of 8
  // for Fref of 0.856 MHz.
  _PLLPRE = 6; // Prescale = PLLPRE + 2
  // Fvco after multiply must be between 100 and 200 MHz.
  // Pick 160 MHz, so multiply by 187.
  _PLLDIV = 185; // Multiply = PLLDIV + 2
  // Final desired Fosc = 80 MHz for an Fcy = 40 MHz.
  // (See 7.7 of the FRM rev B). Pick 80 MHz, so postscale by 2.
  _PLLPOST = 0; // Postscale = 2 * (PLLPOST + 1)
  switchClock(OSC_SEL_BITS);
}
#endif

#if IS_CLOCK_CONFIG(PRIPLL_7372KHzCrystal_40MHzFCY)
#warning Clock configured for PRIPLL using a 7.3727 Mhz primary oscillator, FCY = 40 MHz
void configClock(void) {
  // To be safe: if this was run by a bootloader that chose PRIPLL mode,
  // then we can't change the bits below. To do so, first switch to FRC,
  // change bits, then switch back to PRIPLL.
  switchClock(GET_OSC_SEL_BITS(FNOSC_FRC));
  //settings for Cycle time = 40 MHz, primary oscillator with PLL
  _PLLPRE = 4; // Prescale = PLLPRE + 2
  _PLLDIV = 128; // Multiply = PLLDIV + 2
  _PLLPOST = 0; // Postscale = 2 * (PLLPOST + 1)
  switchClock(OSC_SEL_BITS);
}
#endif

#if IS_CLOCK_CONFIG(PRIPLL_8MHzCrystal_40MHzFCY)
#warning Clock configured for PRIPLL using an 8.0 Mhz primary oscillator, FCY = 40 MHz
/// \todo Not tested.
void configClock(void) {
  //settings for Cycle time = 40 MHz, primary oscillator with PLL
  //These PLL settings will give an FCY == Crystal Freq * 10/2, or FOSC = Crystal Freq * 10
  /*
  This settings assumes the external crystal on is 8.0MHz
  */
  // To be safe: if this was run by a bootloader that chose PRIPLL mode,
  // then we can't change the bits below. To do so, first switch to FRC,
  // change bits, then switch back to PRIPLL.
  switchClock(GET_OSC_SEL_BITS(FNOSC_FRC));
  _PLLPRE = 0; // Prescale = PLLPRE + 2
  _PLLDIV = 38; // Multiply = PLLDIV + 2
  _PLLPOST = 0; // Postscale = 2 * (PLLPOST + 1)
  switchClock(OSC_SEL_BITS);
}
#endif
