
use ActiveState::Run qw(run);
use File::Copy;

#explorer16_100p
&do_compile("SConstruct","explorer16_100p_p", ["DEVICE=24FJ128GA010", "CFLAG1=EXPLORER16_100P"]);
&do_compile("SConstruct","explorer16_100p_p", ["DEVICE=24HJ256GP610", "CFLAG1=EXPLORER16_100P"]);


## 28-pin devices
&do_compile("SConstruct","p", ["DEVICE=24HJ32GP202"]);
&do_compile("SConstruct","p",["DEVICE=24FJ32GA002"]);
&do_compile("SConstruct","p",["DEVICE=24FJ64GA002"]);
&do_compile("SConstruct","p",["DEVICE=24HJ12GP202"]);
&do_compile("SConstruct","p",["DEVICE=24HJ64GP502"]);
&do_compile("SConstruct","p",["DEVICE=24HJ128GP502"]);


## misc
&do_compile("SConstruct","p",["DEVICE=24HJ256GP206"]);
&do_compile("SConstruct","p",["DEVICE=24FJ64GA006"]);
&do_compile("SConstruct","p",["DEVICE=24FJ128GA006"]);
&do_compile("SConstruct","p",["DEVICE=24HJ128GP506"]);
&do_compile("SConstruct","p",["DEVICE=33FJ32GP202"]);
&do_compile("SConstruct","p",["DEVICE=33FJ128GP802"]);
exit;



sub do_compile {
 my($sfile,$prefix,$lref) = @_;
 my($cmd);
 my($hexfile);
 my($flag);
 my (@words);
 my ($dev);
 
 $cmd = "scons -f ". $sfile;
 foreach $flag (@$lref) {
   $cmd = $cmd . " " . $flag;
   @words = split("=",$flag);
   if ($words[0] eq "DEVICE") {
       $dev = $words[1];
     }
   }
 run($cmd);
 $cmd = "pic30-bin2hex.exe main.cof";
 run($cmd);
 $hexfile = $prefix . $dev . "_57600baud_bootldr.hex";
 copy("main.hex",$hexfile);
 run("scons -c");
 }
 
 