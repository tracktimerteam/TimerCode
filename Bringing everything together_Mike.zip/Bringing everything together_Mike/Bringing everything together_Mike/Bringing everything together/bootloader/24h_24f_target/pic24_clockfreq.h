/*
 * "Copyright (c) 2008 Robert B. Reese, Bryan A. Jones, J. W. Bruce ("AUTHORS")"
 * All rights reserved.
 * (R. Reese, reese_AT_ece.msstate.edu, Mississippi State University)
 * (B. A. Jones, bjones_AT_ece.msstate.edu, Mississippi State University)
 * (J. W. Bruce, jwbruce_AT_ece.msstate.edu, Mississippi State University)
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the authors appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE "AUTHORS" BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE "AUTHORS"
 * HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE "AUTHORS" SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE "AUTHORS" HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Please maintain this header in its entirety when copying/modifying
 * these files.
 *
 *
 */


// Documentation for this file. If the \file tag isn't present,
// this file won't be documented.
/** \file
 *  The clocking options for the PIC24 are chosen in this file.
 *  The resulting settings are used in pic24_clockfreq.c
 *  to configure and switch the oscillator as necessary after the chip
 *  is running.
 *
 *  To choose a clock configuration:
 *  -# Select a value for \ref CLOCK_CONFIG from the table there.
 *  -# If the selected value uses the primary oscillator with
 *     or without the PLL, specify the primary oscillator type
 *     in \ref POSCMD_SEL.
 *
 *  This file provides several useful defines as a result of the
 *  clock selection process above:
 *  - \ref CLOCK_CONFIG itself, although this is not typically
 *    directly useful. To determine which clock configuration
 *    was chosen, use the \ref IS_CLOCK_CONFIG macro.
 *  - The oscillator source as a configuration word (\ref FNOSC_SEL)
 *    and as a COSC/NOSC bitfield in the OSCCON register
 *    (\ref OSC_SEL_BITS).
 *  - The processor clock frequency \ref FCY.
 *  - The primary oscillator type \ref POSCMD_SEL.
 *  - The primary oscillator freqency \ref POSC_FREQ.
 *
 *  To define a new clock configuation:
 *  - Add a \#define to the table (see the section
 *    "#defines for CLOCK_CONFIG").
 *  - Add a configClock() function which sets up
 *    and typically switches to that clock to
 *    \ref pic24_clockfreq.c.
 */

#ifndef _PIC24_CLOCKFREQ_H_
#define _PIC24_CLOCKFREQ_H_

///@{ \name Clock configuration
/** Clock configuration for the PIC24 - set CLOCK_CONFIG
 *  to one of the following. Naming convention is
 *  OSCTYPE_[PRIFREQ]_FCYFREQ where OSCTYPE gives the
 *  oscillator type (see \ref FNOSC_SEL for details),
 *  the optional PRIFREQ specifies primary oscillator frequency,
 *  and FCYFREQ determiens the processor clock
 *  (F<sub>CY</sub>) frequency. The "#defines for CLOCK_CONFIG"
 *  section gives the definition of the values below.
 *
 *  \todo If a value chosen for CLOCK_CONFIG is a
 *        valid \#define but not a value from the
 *        table, very confusing compiler errors
 *        are generated. Not sure how to check this.
 *
 *  \code
 *  Name                            uP
 *  ---------------                 ---
 *  SIM_CLOCK (simulator)           any
 *  FRCPLL_FCY16MHz                 24F
 *  FRC_FCY4MHz                     24F
 *  PRIPLL_8MHzCrystal_16MHzFCY     24F
 *  PRI_NO_PLL_7372KHzCrystal       24F, 24H
 *  FRC_FCY3685KHz                  24H
 *  FRCPLL_FCY40MHz                 24H
 *  PRIPLL_7372KHzCrystal_40MHzFCY  24H
 *  PRIPLL_8MHzCrystal_40MHzFCY     24H
 *  \endcode
 */
// For convenience, choose the fastest
// possible clock depending on which
// processor we're using. If simulation mode is
// selected, then use the simulation clock.
#ifndef CLOCK_CONFIG
#if defined(SIM)
#define CLOCK_CONFIG SIM_CLOCK
#elif defined(EXPLORER16_100P) && defined(__PIC24H__)
#define CLOCK_CONFIG PRIPLL_8MHzCrystal_40MHzFCY
#elif defined(EXPLORER16_100P) && defined(__PIC24F__)
#define CLOCK_CONFIG PRIPLL_8MHzCrystal_16MHzFCY
#elif defined(__PIC24H__) || defined(__DOXYGEN__)
#define CLOCK_CONFIG FRCPLL_FCY40MHz
#elif defined(__PIC24F__) 
#define CLOCK_CONFIG FRCPLL_FCY16MHz
#elif defined(__dsPIC33F__)
#define CLOCK_CONFIG FRCPLL_FCY40MHz
#else
#error Unknown processor
#endif
#endif


/** If the selected \ref CLOCK_CONFIG uses the primary oscillator
 *     with or without the PLL, specify the primary oscillator
 *     type here by uncommenting one of the \#defines below.
 *     Otherwise, this value is
 *     automatically set to POSCMD_NONE. Values:
 *  \code
 *      POSCMD_EC            External clock
 *      POSCMD_XT            XT oscillator (for crystals from 3.5 MHz to 10 MHz)
 *      POSCMD_HS            HS oscillator (for crystals from 10 MHz to 32 MHz)
 *  \endcode
 */
#ifndef POSCMD_SEL
//#define POSCMD_SEL POSCMD_EC  // External clock
//#define POSCMD_SEL POSCMD_XT  // XT oscillator
#define POSCMD_SEL POSCMD_HS  // HS oscillator
#endif
///@}

///@{ \name #defines for CLOCK_CONFIG
/** Create a table of vales for CLOCK_CONFIG.
 *  When adding a new entry, you must also write
 *  C code to configure the clock in \ref pic24_clockfreq.c.
 *  See that file for examples and the detailed description
 *  section at the top of this page for more information.
 *  Note that \ref FCY and
 *  \ref POSC_FREQ should be defined as a long (with a
 *  trailing L) to retain enough accuracy to store
 *  these values.
 *
 *  Table entry notes: (see actual code, not the
 *  documentation, for the table)
 *  - Use -1 for don't-care values
 *  - The "unique index" just means each clock configuration
 *    should be assigned a different number. Giving two
 *    configurations the same index will cause problems!
 *  - The processor field should evaluate to a Boolean value
 *    which is true if the processor under which this file
 *    is compiled is supported. Later in this file, the
 *    values PIC24F_DEFINED and PIC24H_DEFINED are set to
 *    true (1) or false (0) based on which processor this
 *    file is compiled with. Use these values in the
 *    Boolean expression. For example:
 *    - 1 (works on any processor)
 *    - PIC24H_DEFINED (works only on the PIC24H)
 *    - PIC24F_DEFINED || PIC24H_DEFINED
 *     (works on PIC24F and PIC24H).
 *  - Valid entries for \ref FNOSC_SEL are defined documentation
 *    for that variable.
 */
//  Table entries are:
//      #define name                    Unique index  FNOSC_SEL     FCY        POSC_FREQ  Processor                           Magic number of 498
//      ------------------------------  ------------  ------------  ---------  ---------  --------------------------------    -------------------
#define SIM_CLOCK                       0,            -1,            1000000L,       -1,  1,                                  498
#define FRCPLL_FCY16MHz                 1,            FNOSC_FRCPLL, 16000000L,       -1,  PIC24F_DEFINED,                     498
#define FRC_FCY4MHz                     2,            FNOSC_FRC,     4000000L,       -1,  PIC24F_DEFINED,                     498
#define PRI_NO_PLL_7372KHzCrystal       3,            FNOSC_PRI,     3686400L, 7372800L,  (PIC24F_DEFINED || PIC24H_DEFINED || dsPIC33F_DEFINED), 498
#define FRC_FCY3685KHz                  4,            FNOSC_FRC,     3685000L,       -1,  (PIC24H_DEFINED|| dsPIC33F_DEFINED),                     498
#define FRCPLL_FCY40MHz                 5,            FNOSC_FRCPLL, 40000000L,       -1,  (PIC24H_DEFINED || dsPIC33F_DEFINED),                     498
#define PRIPLL_7372KHzCrystal_40MHzFCY  6,            FNOSC_PRIPLL, 40000000L, 7372800L,  (PIC24H_DEFINED || dsPIC33F_DEFINED),                     498
#define PRIPLL_8MHzCrystal_40MHzFCY     7,            FNOSC_PRIPLL, 40000000L, 8000000L,  (PIC24H_DEFINED || dsPIC33F_DEFINED),                     498
#define PRIPLL_8MHzCrystal_16MHzFCY     8,            FNOSC_PRIPLL, 16000000L, 8000000L,  (PIC24F_DEFINED || dsPIC33F_DEFINED),                     498
#define PRI_NO_PLL_14745KHzCrystal      9,            FNOSC_PRI,     7372800L, 14745600L,  (PIC24F_DEFINED || PIC24H_DEFINED || dsPIC33F_DEFINED), 498
///@}


#ifndef __DOXYGEN__ // The following non-standard #if confuses Doxygen
// Check to make sure the CLOCK_CONFIG choice selected
// exists and is valid. Otherwise, the compiler emits some very
// confusing errors. Cute hack: the last value in the #define
// above (the magic number) is what the #if tests.
#if (CLOCK_CONFIG != 498)
#error ***********************************************************************
#error * Value chosen for CLOCK_CONFIG does not exist or is not valid!       *
#error * This produces very confusing compiler errors below.                 *
#error ***********************************************************************
#endif
#endif

// Turn clock config type info the right #defines, using
// a three step process:
// Step 1. Just use another macro to turn params (viewied as one argument here)
//         to multiple arguments to the underscore version of the macro
/// \cond nodoxygen
#define GET_CLOCK_CONFIG_INDEX(params) _GET_CLOCK_CONFIG_INDEX(params)
#define GET_FNOSC_SEL(params)          _GET_FNOSC_SEL(params)
#define GET_FCY(params)                _GET_FCY(params)
#define GET_POSC_FREQ(params)          _GET_POSC_FREQ(params)
#define GET_IS_SUPPORTED(params)       _GET_IS_SUPPORTED(params)

// Step 2. Return the desired parameter, now that params are seen as
//         individual arguments.
#define _GET_CLOCK_CONFIG_INDEX(ndx, oscSel, Fcy, poscFreq, isSupported, magic) ndx
#define _GET_FNOSC_SEL(ndx, oscSel, Fcy, poscFreq, isSupported, magic)          oscSel
#define _GET_FCY(ndx, oscSel, Fcy, poscFreq, isSupported, magic)                Fcy
#define _GET_POSC_FREQ(ndx, oscSel, Fcy, poscFreq, isSupported, magic)          poscFreq
#define _GET_IS_SUPPORTED(ndx, oscSel, Fcy, poscFreq, isSupported, magic)       isSupported
// Step 3. Call the macros above to set constants based on the
//         clock config selected.
/// \endcond
#define CLOCK_CONFIG_INDEX GET_CLOCK_CONFIG_INDEX(CLOCK_CONFIG)
#define FNOSC_SEL          GET_FNOSC_SEL(CLOCK_CONFIG)
#define FCY                GET_FCY(CLOCK_CONFIG)
#define POSC_FREQ          GET_POSC_FREQ(CLOCK_CONFIG)
// Verify that the current processor is supported by the clock
// configuration chosen.
// 1. Set up some #defines as booleans which tell which processor
//    is selected for this compile.
/// \cond nodoxygen
#ifdef __PIC24F__
#define PIC24F_DEFINED 1
#else
#define PIC24F_DEFINED 0
#endif
#ifdef __PIC24H__
#define PIC24H_DEFINED 1
#else
#define PIC24H_DEFINED 0
#endif
#ifdef __dsPIC33F__
#define dsPIC33F_DEFINED 1
#else
#define dsPIC33F_DEFINED 0
#endif


// 2. Check to see if this clock configuration supports that processor.
#if !GET_IS_SUPPORTED(CLOCK_CONFIG)
#error The clock configuration chosen is not supported by this processor.
#endif
/// \endcond

///@{ \name Some of the #defines produced by CLOCK_CONFIG choice
/** \def FNOSC_SEL
 *  Oscillator source selection for the PIC24. FNOSC_SEL
 *  is set to one of the following based on
 *  \ref CLOCK_CONFIG :
 *  \code
 *      Name                 Description                                    PIC24F  PIC24H
 *      -------------        --------------------------------------------   ------  ------
 *      FNOSC_FRC            Fast RC oscillator                                X      X
 *      FNOSC_FRCPLL         Fast RC oscillator w/ divide and PLL              X      X
 *      FNOSC_PRI            Primary oscillator (XT, HS, EC)                   X      X
 *      FNOSC_PRIPLL         Primary oscillator (XT, HS, EC) w/ PLL            X      X
 *      FNOSC_SOSC           Secondary oscillator                              X      X
 *      FNOSC_LPRC           Low power RC oscillator                           X      X
 *      FNOSC_FRCDIV         Fast RC oscillator with divide                    X
 *      FNOSC_FRCDIV16       Fast RC oscillator w/ divide by 16                       X
 *      FNOSC_LPRCDIVN       Low power Fast RC oscillator w/divide by N               X
 \endcode
 */

/** \def FCY
 *  FCY specifies the resulting processor clock frequency after
 *  all PLL/divide operations take the inital clock and produce
 *  a processor clock. The units of this value are Hz, so the
 *  value 40000000L is 40 MHz.
 *
 *  NOTE: This should be defined as a long (with a trailing L
 *  after the number) to allocate enough space to correctly
 *  store the processor clock frequency.
 */

/** \def POSC_FREQ
 *  This values gives the primary osciallator frequency (if used).
 *  The units of this value are Hz, so the value 40000000L is 40 MHz.
 *
 *  NOTE: This should be defined as a long (with a trailing L
 *  after the number) to allocate enough space to correctly
 *  store the processor clock frequency.
*/

/** \def OSC_SEL_BITS
 *  A macro giving the NOSC/COSC bits
 *  for the OSCCON register
 *  which correspond to \ref FNOSC_SEL,
 *  the configuration word which contains
 *  the FNOSC bits.
 */
///@}


///@{ \name Helper macros for clock configuration
/** A helper macro to check if the given clock configuration
 *  was selected. Example usage is given in
 *  \ref pic24_clockfreq.c. A shorter example:
 *  \code
 *  #if IS_CLOCK_CONFIG(FRCPLL_FCY40MHz)
 *  ... code only included if CLOCK_CONFIG is FRCPLL_FCY40MHz ...
 *  #endif
 *  \endcode
 *  \param clockConfig Clock configuration to compare the current
 *         clock configuation against.
 */
#define IS_CLOCK_CONFIG(clockConfig) _GET_CLOCK_CONFIG_INDEX(clockConfig) == CLOCK_CONFIG_INDEX

/** A macro to determine the NOSC/COSC bits
 *  for the OSCCON register given bits taken
 *  from the PIC24's configuration FNOSC word.
 */
#define GET_OSC_SEL_BITS(bits) _GET_OSC_SEL_BITS(bits)
/// \cond nodoxygen
#if defined(__PIC24H__) || defined(__dsPIC33F__) || defined(__DOXYGEN__)
#define _GET_OSC_SEL_BITS(bits) ((bits >> 0) & 0x07)
#elif defined (__PIC24F__) 
#define _GET_OSC_SEL_BITS(bits) ((bits >> 8) & 0x07)
#else
#error Unknown processor
#endif
/// \endcond
///@}
#define OSC_SEL_BITS GET_OSC_SEL_BITS(FNOSC_SEL)

// Double check to make sure the oscillator selection above is valid.
#if ( (OSC_SEL_BITS < 0) || (OSC_SEL_BITS > 7) )
#error Invalid oscillator selection FNOSC_SEL.
#endif

// For some reason, primary oscillator selections are named
// POSCMD_xx in the PIC24H and POSCMOD_xx in the PIC24F.
// Work around this.
// Hopefully, this will be defined in PIC24F headers at some point
/// \cond nodoxygen
#ifndef POSCMD_EC
#define POSCMD_EC   POSCMOD_EC
#define POSCMD_XT   POSCMOD_XT
#define POSCMD_HS   POSCMOD_HS
#define POSCMD_NONE POSCMOD_NONE
#endif
/// \endcond


// If weren't not using the primary oscillator, with
// or without the PLL, then turn it off.
#if (FNOSC_SEL != FNOSC_PRI) && (FNOSC_SEL != FNOSC_PRIPLL)
#undef POSCMD_SEL
// The primary oscialltor is not used, so disable it.
#define POSCMD_SEL POSCMD_NONE
#endif


/** Switch the clock to the source specified. The source
 *  given will be assigned to NOSC in the OSCCON register,
 *  the a switch clock performed.
 *
 *  Note: <b>DO NOT</b> use \ref FNOSC_SEL as the source;
 *  instead, use \ref OSC_SEL_BITS. FNOSC_SEL is for
 *  configuration bits while switchClock
 *  expects a NOSC value to write to the
 *  OSCCON register.
 *
 * \param u8_source The clock source to switch to.
 */
void switchClock(uint8 u8_source);

/** Configure the clock. See \ref pic24_clockfreq.c
 *  for an example of this function. Note that
 *  this function's contents vary with the
 *  \ref CLOCK_CONFIG chosen.
 */
void configClock(void);

#endif
