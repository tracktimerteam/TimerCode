#include "pic24_all.h"
#include "mp3_spi.h"
#include <stdio.h>


void configSPI2(void) {
	SPI2STAT = 0;
	SPI2CON1 = 0;
	SPI2CON2 = 0;

  //spi clock = 40MHz/4*4 = 40MHz/16 = 2.50MHz
  SPI2CON1 = SEC_PRESCAL_4_1 |     //4:1 secondary prescale
             PRI_PRESCAL_4_1 |     //4:1 primary prescale
             CLK_POL_ACTIVE_HIGH   | //clock active high (CKP = 0)
             //SPI_CKE_OFF          | //out changes inactive to active (CKE=0)
			SPI_CKE_ON				| //CKE = 1
             SPI_MODE8_ON        | //8-bit mode
             MASTER_ENABLE_ON;     //master mode
  //configure pins. Need SDO,SDI, SCLK (RG6,7,8)
  /*CONFIG_SDO1_TO_RC1(3);      //use RC1 for SDO
  CONFIG_RC1_AS_DIG_PIN();   //Ensure that analog is disabled
  CONFIG_SCK1OUT_TO_RC(2);   //use RC2 for SCLK
  CONFIG_RC2_AS_DIG_PIN();   //Ensure that analog is disabled
  CONFIG_SDI1_TO_RG(15);      //use RG15 for SDI
  CONFIG_RG15_AS_DIG_PIN();   //Ensure that analog is disabled
  */

  //CONFIG_RB14_AS_DIG_OUTPUT();		//Bit_Sync RB14
  CONFIG_RC2_AS_DIG_INPUT();		//DREQ RC2
  CONFIG_RC1_AS_DIG_OUTPUT();		//RESET RC1

  CONFIG_SLAVE_ENABLE();       //chip select for MCP41xxx
  SLAVE_DISABLE();             //disable the chip select
  SPI2STATbits.SPIEN = 1;  //enable SPI mode
}

void Hard_Reset(){
	SLAVE_DISABLE();
	Reset=0;
	Reset=1;
	//printf("MP3 Reset \n");
}

void Soft_Reset(){
	SLAVE_ENABLE();
	ioMasterSPI2(0x02);
	ioMasterSPI2(0x00);
	ioMasterSPI2(0x00);
	ioMasterSPI2(0x04);
	SLAVE_DISABLE();
}

uint8 writeMP3Reg(uint8 u8RegisterAddr, uint8 UpBytes, uint8 LowBytes){
     /*
     * Checks if Data Request is high. If not the decoder is not ready
     * to recieve information.
     */
    SLAVE_ENABLE();
  
    if (DREQ){
        ioMasterSPI2(WRITE); 
        ioMasterSPI2(u8RegisterAddr);
        ioMasterSPI2(UpBytes);
        ioMasterSPI2(LowBytes);
		
        SLAVE_DISABLE();
		return 1;
    }
    return 0; 
 }


uint16 readMP3Reg(uint8 u8RegisterAddr){
 	uint16 u16RegisterValue;
    uint8  u8LSBRegister;
    /*
     * Checks if Data Request is high. If not the decoder is not ready
     * to recieve information.
     */
    SLAVE_ENABLE();
  
    if (DREQ){
        ioMasterSPI2(READ);
        //outUint8(u8LSBRegister);  
        ioMasterSPI2(u8RegisterAddr);
        //outUint8(u8LSBRegister);
        //outString("\r\n");

        u16RegisterValue = ioMasterSPI2(0xA5);
		//u16RegisterValue = ioMasterSPI1(0x00);
        u8LSBRegister = ioMasterSPI2(0x5A);
		//u8LSBRegister = ioMasterSPI1(0x00);
        u16RegisterValue = (u16RegisterValue << 8) | u8LSBRegister;
        SLAVE_DISABLE();

	    return u16RegisterValue;  
    }
    return 0x0000; 
 }

void Start_Sine_Test(){
		SLAVE_DISABLE();
		ioMasterSPI2(0x53);
		ioMasterSPI2(0xEF);
		ioMasterSPI2(0x6E);
		ioMasterSPI2(0x44);
		ioMasterSPI2(0x00);
		ioMasterSPI2(0x00);
		ioMasterSPI2(0x00);
		ioMasterSPI2(0x00);
		SLAVE_ENABLE();
}

void Stop_Sine_Test(){
		SLAVE_DISABLE();
		ioMasterSPI2(0x45);
		ioMasterSPI2(0x78);
		ioMasterSPI2(0x69);
		ioMasterSPI2(0x74);
		ioMasterSPI2(0x00);
		ioMasterSPI2(0x00);
		ioMasterSPI2(0x00);
		ioMasterSPI2(0x00);
		SLAVE_ENABLE();
}

void MP3_Config(){
	Hard_Reset();
	printf("\n Hardware Reset \n");

	//DELAY_MS(5000);

	//Software Reset
	if(DREQ){
		Soft_Reset();
		printf("Software reset \n");
	}

	while(!DREQ);

	if(writeMP3Reg(0x00,0x0c,0x40)){
		printf("MP3 config'd \n");
	}

	if(writeMP3Reg(0x03,0x98,0x00)){	//0x98 0x00 or 0x18 0x00
		printf("Clock config'd \n");
	}

	//if(writeMP3Reg(0x0B,0x00,0x01)){
	//if(writeMP3Reg(0x0B,0x00,0x07)){
	if(writeMP3Reg(0x0B,0x00, 0x00)){
		printf("Volume Set \n");
	}
	//if(writeMP3Reg(0x02,0x7a,0x00)){
	//	printf("Treble Boost \n");
	//}
	
	//try to read
/*	uint16 reginfo;
	uint8  upinfo;
	uint8  lowinfo;

	reginfo = 0;
	upinfo = 0;
	lowinfo = 0;
	
	while(reginfo==0){
		reginfo = readMP3Reg(0x0B);
	}
	
	lowinfo = (reginfo & 0x00FF);
	upinfo = ((reginfo >> 8) & 0xFF);

	if(reginfo==0){
		printf("Read unsuccessful \n");
	}
	else{
		printf("Upper info = %X",upinfo);
		printf("\n");
		printf("Lower info = %X",lowinfo);
		printf("\n");
	}*/
}

uint16 Check_MP3(){
	uint16 hdat1, hdat2;
	hdat1 = 0;
	hdat2 = 0;

	hdat1 = readMP3Reg(0x08);
	//hdat2 = readMP3Reg(0x09);
	
	//if(hdat1 | hdat2){
	if(hdat1){
		//return 1;
		return hdat1;
	}
	else{
		return 0;
	}
}
