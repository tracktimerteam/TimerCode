/*******************************************
 * Written by the "Music Alarm Clock" team *
 *******************************************/

#include "pic24_all.h"
#include "get_time.h"

/***************************************************** 
 *  Time information from the atomic signal receiver *
 *  stored in the wwvbdata array is proccessed and	 * 
 *  the values of time are returned				 	 *
 *****************************************************/

inline void CONFIG_PINS() {
	CONFIG_RD0_AS_DIG_OUTPUT();     // PWM for clock
	CONFIG_RD1_AS_DIG_OUTPUT();     // PON 
	CONFIG_RF4_AS_DIG_INPUT();      // Data
	CONFIG_RD8_AS_DIG_OUTPUT();     // Data Send Clock
	CONFIG_RF5_AS_DIG_INPUT();     	// Data Ready DR
	CONFIG_RF6_AS_DIG_OUTPUT();     // Hold AGC
	CONFIG_RD10_AS_DIG_INPUT();     // BS1
	CONFIG_RD11_AS_DIG_INPUT();    	// BS2
	CONFIG_RF2_AS_DIG_OUTPUT();		// SS2
	CONFIG_RF3_AS_DIG_OUTPUT();		// SS1

	ss1 = 0;
	ss2 = 1;
}

int getMinutes(int wwvbdata1[]){
  int result = 0;
  if (wwvbdata1[5] == 1){result = result + 40;}
  if (wwvbdata1[6] == 1){result = result + 20;}
  if (wwvbdata1[7] == 1){result = result + 10;}
  if (wwvbdata1[9] == 1){result = result + 8;}
  if (wwvbdata1[10] == 1){result = result + 4;}
  if (wwvbdata1[11] == 1){result = result + 2;}
  if (wwvbdata1[12] == 1){result = result + 1;} 
  if (result == 59){result = 1;}else{result = result +1;} 
  return result;
}

int getHour(int wwvbdata1[]){
  int result = 0;
  if (wwvbdata1[16] == 1){result = result + 20;}
  if (wwvbdata1[17] == 1){result = result + 10;}
  if (wwvbdata1[19] == 1){result = result + 8;}
  if (wwvbdata1[20] == 1){result = result + 4;}
  if (wwvbdata1[21] == 1){result = result + 2;}
  if (wwvbdata1[22] == 1){result = result + 1;}
  if (result < timezone){result = result + (24 - timezone);}else{result = result - timezone;}
  return result;
}

int getDays(int wwvbdata1[]){
  int result = 0;
  if (wwvbdata1[26] == 1){result = result + 200;}
  if (wwvbdata1[27] == 1){result = result + 100;}
  if (wwvbdata1[29] == 1){result = result + 80;}
  if (wwvbdata1[30] == 1){result = result + 40;}
  if (wwvbdata1[31] == 1){result = result + 20;}
  if (wwvbdata1[32] == 1){result = result + 10;}
  if (wwvbdata1[34] == 1){result = result + 8;}
  if (wwvbdata1[35] == 1){result = result + 4;}
  if (wwvbdata1[36] == 1){result = result + 2;}
  if (wwvbdata1[37] == 1){result = result + 1;}
  return result;
}

int getMonth(int wwvbdata1[]){
int days = getDays(wwvbdata1);
int total = 0;
total = total + 31; if (total > days){return 0;}
if (wwvbdata1[59] == 1){total = total + 28;}else{total = total + 29;} if (total > days){return 1;}
total = total + 31; if (total > days){return 2;}
total = total + 30; if (total > days){return 3;}
total = total + 31; if (total > days){return 4;}
total = total + 30; if (total > days){return 5;}
total = total + 31; if (total > days){return 6;}
total = total + 31; if (total > days){return 7;}
total = total + 30; if (total > days){return 8;}
total = total + 31; if (total > days){return 9;}
total = total + 30; if (total > days){return 10;}
total = total + 31; if (total > days){return 11;}  

return 0;
}

int getDayofMonth(int wwvbdata1[]){
int day;
int days = getDays(wwvbdata1);
int total = 1;  //count of days starts with day 1, not 0.
total = total + 31; if (total > days){day = days; return day;}
if (wwvbdata1[59] == 1){total = total + 28;}else{total = total + 29;} if (total > days){if (wwvbdata1[59] == 1){day = days - (total - 28);}else{day = days - (total - 29);} return day;}
total = total + 31; if (total > days){day = days - (total - 31); return day;}
total = total + 30; if (total > days){day = days - (total - 30); return day;}
total = total + 31; if (total > days){day = days - (total - 31); return day;}
total = total + 30; if (total > days){day = days - (total - 30); return day;}
total = total + 31; if (total > days){day = days - (total - 31); return day;}
total = total + 31; if (total > days){day = days - (total - 31); return day;}
total = total + 30; if (total > days){day = days - (total - 30); return day;}
total = total + 31; if (total > days){day = days - (total - 31); return day;}
total = total + 30; if (total > days){day = days - (total - 30); return day;}
total = total + 31; if (total > days){day = days - (total - 31); return day;}  

return 0;
}

//get year
int getYear(int wwvbdata1[]){
  int result = 0;
  if (wwvbdata1[49] == 1){result = result + 80;}
  if (wwvbdata1[50] == 1){result = result + 40;}
  if (wwvbdata1[51] == 1){result = result + 20;}
  if (wwvbdata1[52] == 1){result = result + 10;}
  if (wwvbdata1[54] == 1){result = result + 8;}
  if (wwvbdata1[55] == 1){result = result + 4;}
  if (wwvbdata1[56] == 1){result = result + 2;}
  if (wwvbdata1[57] == 1){result = result + 1;}
  result = result + 2000;
  return result;
}
