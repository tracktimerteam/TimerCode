#include "pic24_all.h"
#include "vdip_spi.h"
#include "vdip_func.h"
#include <stdio.h>
#include <stdlib.h>

#define RESET _LATB5					//RESET is RB5
#define file_buf  12+11				//10 files + desktop.ini = 12 * # of songs on drive

#define usb_status_led	_LATF2

char file_data[file_buf];


void VDIP_Reset(){
	uint8 i;
	CONFIG_RB5_AS_DIG_OUTPUT();		
	RESET = 0;
	DELAY_MS(500);
	RESET = 1;
	DELAY_MS(500);
	printf("VDIP1 Reset \n");
	//_LATB2 = 1;
	DELAY_MS(2000);
	/*for(i=0;i<=file_buf;i++){		//initialize file_data array
		file_data[i] = 0;
	}*/
}

void Sync_E(){
	printf("Sync_E started \n");
	spiWrite('E');						//sends 'E' to VDIP
	printf("E sent \n");
	spiWrite(0x0D);
	printf("Carriage return sent \n");
	printf("E finished \n");
}

void Sync_e(){
	printf("Sync_e started \n");
	spiWrite(0x65);						
	spiWrite(0x0D);
	printf("Sync_e finished \n");
}

void SCS(){
	spiWrite(0x10);
	spiWrite(0x0D);
}

void Check_Disk(){
	spiWrite(0x0D);
}

void List_Files(){
	spiWrite(0x01);
	spiWrite(0x0D);
}

void Rand_File(char disk_info[]){
	int i, count, rand_int, state;
	i = 0;
	count = 0;
	rand_int = 0;
	state = 1;
	

//find random starting place
		rand_int = rand() % file_buf;			//picks random number btwn 0 and file_buf
		//rand_int = 125;
		//printf("random int = %d",rand_int);
		//printf("\n");

		i = rand_int;
	
//choose a file from disk_info	
	while(state == 1){
		//if(i>file_buf){
		if(i>(file_buf-11)){							
			i=0;
			state = 0;
		}	
		if(disk_info[i] == '.' && disk_info[i+4] != 'D' && disk_info[i+5] !='E'){
		//if(disk_info[i] == '.'){
			count = i+4;			//increments past '.mp3'
			state = 0;
		}
		i++;
	}

//write command to read chosen file	
	printf("\n");

	spiWrite(0x04);
	spiWrite(0x20);
	
	printf("printing file name \n");	
	while(disk_info[count] != '.'){
		spiWrite(disk_info[count]);
		printf("%c",disk_info[count]);
		count++;
	}
	spiWrite(disk_info[count]);		//spiWrite '.'
	printf("%c",disk_info[count]);
	count++;								
	spiWrite(disk_info[count]);		//spiWrite file extension
	printf("%c",disk_info[count]);
	count++;
	spiWrite(disk_info[count]);		//spiWrite file extension
	printf("%c",disk_info[count]);
	count++;
	spiWrite(disk_info[count]);		//spiWrite file extension
	spiWrite(0x0D);
	printf("%c",disk_info[count]);
	count++;
	printf("\n");
}

///////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////
void VDIP_Init(){
	spiInit();							//initializes SPI
	printf("SPI initialized\n");

	VDIP_Reset();						//resets VDIP
	printf("VDIP1 Reset \n");
}

void VDIP_Sync(){
	char data;
    data = 0;

	Sync_E();							//sends 'E' to VDIP
	//printf("Waiting for E... \n");
	//_LATB2 = 1;

	while (data != 'E'){				//PIC waits to get 'E' back
		//printf("Waiting for E \n");
		_LATB2 = 1;
		data = spiReadWait();
		printf("%c",data);
	}
	printf("\n");

	data = spiReadWait();				//read the carriage return
	printf("data = %c",data);	
	printf("\n");

	Sync_e();							//sends 'e' to VDIP
	
	data = spiReadWait();				//check if 'e' was sent back on first try
	if (data == 'e'){
		printf("%c",data);
		printf("\nVDIP1 Sync'd \n");
	}	
	spiReadWait();	//read the carriage return
}

void VDIP_SCS(){
	char data;
	data = 0;

	SCS();								//puts VDIP in short command set

	data = spiReadWait();				//check if command was accepted

	if(data == '>'){
		printf("Entered Short Command Set \n");
	}
	else{
		printf("Error \n");
	}
		
	spiReadWait();						//read the carriage return
}

uint8 VDIP_CheckDisk(){
		char data;
		uint8 state;
		data = 0;
		state = 0;

		Check_Disk();					//checks for disk in VDIP
		
		data = spiReadWait();		
		if(data == '>'){					//	//check if command wss accepted
			printf("Disk recognized \n");
			state = 1;
		}
		if(data == 'N'){				//ND = no disk
			data = spiReadWait();
		}
		if(data == 'D'){
			printf("No disk \n");
			state = 0;
		}
 		spiReadWait();	//read the carriage return
		//spiReadWait();
		
	return state;
}

uint8 VDIP_ListFiles(){
	char data; 
	//data = 0;
	uint8 i, state;
	state = 1;

	//CONFIG_RA2_AS_DIG_OUTPUT();
	usb_status_led = 0;
	
				
	for(i=0;i<=file_buf;i++){		//initialize file_data array
		file_data[i] = 0;
	}

	i = 0;
	
	VDIP_Sync();
	
	List_Files();					//lists files on drives
	printf("Got Files \n");
		

	while(state){					//fills file_data array with the file list
		data = spiReadWait();
			if(data != '>' && data != 0x0D && i<file_buf){
				file_data[i] = data; 
				i++;
			}
			if(data == '>'){ 
				data = spiReadWait();		//get carriage return
				if(data == 0x0D)
				{
					//break;
					state = 0;
				}
			}
	}


	printf("\n");
	printf("Printing File List \n");

	for(i=0;i<=file_buf;i++){		//displays file list to screen	
		printf("%c",file_data[i]);
	}
	
	i = 0;	
	state = 0;
	//while(i<=(file_buf-4)){					//check for mp3 file on flash drive
   while(state == 0){
		while(file_data[i] != '.'){
			i++;
		}
		if(file_data[i] == '.' && file_data[i+1] == 'M' && file_data[i+2] == 'P' && file_data[i+3] == '3'){
			state = 1;
			usb_status_led = 1;
		}
		else{
			//state = 0;
			usb_status_led = !usb_status_led;
			DELAY_MS(500);
			i++;
		}	
  }
	return state;		
}

void VDIP_ReadRand(){
	char data;
	data = 1;

	Rand_File(file_data);			//chooses and reads random file

	

	/*while(data){					//outputs file to screen
	//while(data != '>'){
		data = spiReadWait();
		if(data != '>'){
		//if(data){
			//mp3_data[k]=data;
			//k++;
			printf("%c",data);
		}
		if(data == '>'){
			data = spiReadWait();
			break;
		}
	}*/
	
	printf("\n");
	printf("File Read \n"); 
}
