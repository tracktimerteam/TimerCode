/*******************************************
 * Written by the "Music Alarm Clock" team *
 *******************************************/

#include "pic24_all.h"
#include "clock_functions.h"
#include "pic24_i2c.h"

// Switch1 configuration
inline void CONFIG_ALLSW(){
  CONFIG_RC13_AS_DIG_INPUT();   				//use RC13 for On/Off Switch input
  ENABLE_RC13_PULLUP();          				//enable the pullup
  CONFIG_RC14_AS_DIG_INPUT();   				//use RC14 for Minutes Increment Button input
  ENABLE_RC14_PULLUP();          				//enable the pullup
  CONFIG_RD4_AS_DIG_INPUT();    				//use RD4 for Hours Increment Button input
  ENABLE_RD4_PULLUP();          				//enable the pullup
  CONFIG_RD5_AS_DIG_INPUT();    				//use RD5 for Set Button input
  ENABLE_RD5_PULLUP();         				 	//enable the pullup
  CONFIG_RD6_AS_DIG_INPUT();    				//use RD6 for Alarm Set Button input
  ENABLE_RD6_PULLUP();          				//enable the pullup
  CONFIG_RD7_AS_DIG_INPUT();    				//use RD7 for Snooze Button input
  ENABLE_RD7_PULLUP();        					//enable the pullup
}

void WriteInitialTime(uint8 u8_hour, uint8 u8_min, uint8 u8_sec){	//, uint8 u8_year, uint8 u8_month, uint8 u8_days){

	write2I2C1(DS1337ADDR,Control_Addr,0b00000110);

	uint8 ampm = 0;
	if(u8_hour == 24){
		u8_hour = u8_hour - 12;					//subtract 12 from hours
		ampm = 0b01000000;						//ampm = 24 hour and am
	}else if(u8_hour > 12){
		u8_hour = u8_hour - 12;					//subtract 12 from hours
		ampm = 0b01100000;						//ampm = 24 hour and pm
	}else if(u8_hour == 12){
		ampm = 0b01100000;						//ampm = 24 hour and pm
	}else if(u8_hour < 12){
		ampm = 0b01000000;						//ampm = 24 hour and am
	}
	
	//u8_year = u8_year - 2000;
	//u8_year = DecimalToHex(u8_year);
	//u8_month = DecimalToHex(u8_month);
	//u8_days = DecimalToHex(u8_days);
	u8_hour = DecimalToHex(u8_hour);			//turns decimal into hex
	u8_min = DecimalToHex(u8_min);
	u8_sec = DecimalToHex(u8_sec);

	u8_hour = (u8_hour | ampm);					//converts hours for clock chip

	//write2I2C1(DS1337ADDR,Year_Addr,u8_year);
	//write2I2C1(DS1337ADDR,Month_Addr,u8_month);
	//write2I2C1(DS1337ADDR,Days_Addr,u8_days);
	write2I2C1(DS1337ADDR,Hour_Addr,u8_hour);
	write2I2C1(DS1337ADDR,Min_Addr,u8_min);
	write2I2C1(DS1337ADDR,Sec_Addr,u8_sec);
}

void WriteTime(uint8 u8_hour, uint8 u8_min, uint8 u8_sec){
	write2I2C1(DS1337ADDR,Hour_Addr,u8_hour);
	write2I2C1(DS1337ADDR,Min_Addr,u8_min);
	write2I2C1(DS1337ADDR,Sec_Addr,u8_sec);
}

void WriteAlarm1Time(uint8 u8_alarmdate, uint8 u8_alarmhour, uint8 u8_alarmmin){
	write2I2C1(DS1337ADDR,Alarm1Date_Addr,u8_alarmdate);
	write2I2C1(DS1337ADDR,Alarm1Hour_Addr,u8_alarmhour);
	write2I2C1(DS1337ADDR,Alarm1Min_Addr,u8_alarmmin);
}

void WriteAlarm2Time(uint8 u8_alarmdate, uint8 u8_alarmhour, uint8 u8_alarmmin){
	write2I2C1(DS1337ADDR,Alarm2Date_Addr,u8_alarmdate);
	write2I2C1(DS1337ADDR,Alarm2Hour_Addr,u8_alarmhour);
	write2I2C1(DS1337ADDR,Alarm2Min_Addr,u8_alarmmin);
}

void WriteStatusReg(uint8 u8_k){write2I2C1(DS1337ADDR,Status_Addr,u8_k);}

void UpdateAlarm(){
	uint8 u8_alarmdate = 0b10000001;
	uint8 u8_alarmhour = ReadAlarm1Hour();
	uint8 u8_alarmmin = ReadAlarm1Min();
	u8_alarmhour = (u8_alarmhour | 0b01000000);			//ampm = 24 hour
	WriteAlarm2Time(u8_alarmdate, u8_alarmhour, u8_alarmmin);
}	

int8 DecimalToHex(uint8 decimal_value){
	uint8 hex_value = 0, first_digit = 0, second_digit = 0;

	//separates each value of the decimal value
	first_digit = decimal_value / 10;					//gets first digit
	second_digit = decimal_value - (first_digit * 10);	//gets second digit
	
	//shifts first digit left by four to prepare for hex
	first_digit = first_digit << 4;
	
	hex_value = (first_digit | second_digit);			//combine digits in hex
	return hex_value;
}

/*int8 ReadYear()
{uint8 u8_year; write1I2C1(DS1337ADDR, Year_Addr); read1I2C1(DS1337ADDR, &u8_year); return u8_year;}

int8 ReadMonth()
{uint8 u8_month; write1I2C1(DS1337ADDR, Month_Addr); read1I2C1(DS1337ADDR, &u8_month); return u8_month;}

int8 ReadDays()
{uint8 u8_days; write1I2C1(DS1337ADDR, Days_Addr); read1I2C1(DS1337ADDR, &u8_days); return u8_days;}*/

int8 ReadHour()
{uint8 u8_hour; write1I2C1(DS1337ADDR, Hour_Addr); read1I2C1(DS1337ADDR, &u8_hour); return u8_hour;}

int8 ReadMin()
{uint8 u8_min; write1I2C1(DS1337ADDR, Min_Addr); read1I2C1(DS1337ADDR, &u8_min); return u8_min;}

int8 ReadSec()
{uint8 u8_sec; write1I2C1(DS1337ADDR, Sec_Addr); read1I2C1(DS1337ADDR, &u8_sec); return u8_sec;}

int8 ReadAlarm1Date()
{uint8 u8_alarmdate; write1I2C1(DS1337ADDR, Alarm1Date_Addr); read1I2C1(DS1337ADDR, &u8_alarmdate); return u8_alarmdate;}

int8 ReadAlarm1Hour()
{uint8 u8_alarmhour; write1I2C1(DS1337ADDR, Alarm1Hour_Addr); read1I2C1(DS1337ADDR, &u8_alarmhour); return u8_alarmhour;}

int8 ReadAlarm1Min()
{uint8 u8_alarmmin; write1I2C1(DS1337ADDR, Alarm1Min_Addr); read1I2C1(DS1337ADDR, &u8_alarmmin);return u8_alarmmin;}

int8 ReadAlarm2Date()
{uint8 u8_alarmdate; write1I2C1(DS1337ADDR, Alarm2Date_Addr); read1I2C1(DS1337ADDR, &u8_alarmdate); return u8_alarmdate;}

int8 ReadAlarm2Hour()
{uint8 u8_alarmhour; write1I2C1(DS1337ADDR, Alarm2Hour_Addr); read1I2C1(DS1337ADDR, &u8_alarmhour); return u8_alarmhour;}

int8 ReadAlarm2Min()
{uint8 u8_alarmmin; write1I2C1(DS1337ADDR, Alarm2Min_Addr); read1I2C1(DS1337ADDR, &u8_alarmmin); return u8_alarmmin;}

int8 ReadStatusReg()
{uint8 u8_stat;	write1I2C1(DS1337ADDR, Status_Addr); read1I2C1(DS1337ADDR, &u8_stat); return u8_stat;}

void MinUp(){
	uint8 u8_hour = ReadHour();
	uint8 u8_min = ReadMin();
	uint8 u8_sec = ReadSec();
	u8_min++;
	uint8 minute = u8_min;
	minute = (minute & 0b00001010);
	if(minute == 0b00001010){u8_min = u8_min + 6;}
	if(u8_min == 0b01100000){u8_min = 0b00000000;}	//if mins = 60
	DELAY_MS(200);									//Delay 1/10 second
	WriteTime(u8_hour, u8_min, u8_sec);
}

void HourUp(){
	uint8 u8_hour = ReadHour();
	uint8 u8_min = ReadMin();
	uint8 u8_sec = ReadSec();
	u8_hour++;								//inc hours
	if(u8_hour == 0b01110010){				//if hours = 24 hour, pm, and 12
		u8_hour = 0b01010010;				//set hours = 24 hour, am, and 12
	}else if(u8_hour == 0b01010010){		//if hours = 24 hour, am, and 12
		u8_hour = 0b01110010;				//set hours = 24 hour, pm, and 12
	}
	if(u8_hour == 0b01101010 || u8_hour == 0b01001010){
		u8_hour = u8_hour + 6;
	}
	if(u8_hour == 0b01110011){				//if hours = 24 hour, pm, and 13
		u8_hour = 0b01100001;				//set hours = 24 hour, pm, and 1
	}else if(u8_hour == 0b01010011){		//if hours = 24 hour, am, and 13
		u8_hour = 0b01000001;				//set hours = 24 hour, am, and 1
	}
	DELAY_MS(200);							//Delay 1/10 second
	WriteTime(u8_hour, u8_min, u8_sec);
}

void AlarmMinUp(){
	uint8 u8_alarmdate = 0b10000001;
	uint8 u8_alarmhour = ReadAlarm2Hour();
	uint8 u8_alarmmin = ReadAlarm2Min();
	u8_alarmmin++;
	uint8 minute = u8_alarmmin;
	minute = (minute & 0b00001010);
	if(minute == 0b00001010){u8_alarmmin = u8_alarmmin + 6;}
	if(u8_alarmmin == 0b01100000){u8_alarmmin = 0b00000000;}	//if mins = 60
	DELAY_MS(200) 												//Delay 1/10 second
	WriteAlarm1Time(u8_alarmdate, u8_alarmhour, u8_alarmmin);
	WriteAlarm2Time(u8_alarmdate, u8_alarmhour, u8_alarmmin);
}

void AlarmHourUp(){
	uint8 u8_alarmdate = 0b10000001;
	uint8 u8_alarmhour = ReadAlarm2Hour();
	uint8 u8_alarmmin = ReadAlarm2Min();
	u8_alarmhour++;							//inc hours
	if(u8_alarmhour == 0b01110010){			//if hours = 24 hour, pm, and 12
		u8_alarmhour = 0b01010010;			//set hours = 24 hour, am, and 12
	}else if(u8_alarmhour == 0b01010010){	//if hours = 24 hour, am, and 12
		u8_alarmhour = 0b01110010;			//set hours = 24 hour, pm, and 12
	}
	if(u8_alarmhour == 0b01101010 || u8_alarmhour == 0b01001010){
		u8_alarmhour = u8_alarmhour + 6;
	}
	if(u8_alarmhour == 0b01110011){			//if hours = 24 hour, pm, and 13
		u8_alarmhour = 0b01100001;			//set hours = 24 hour, pm, and 1
	}else if(u8_alarmhour == 0b01010011){	//if hours = 24 hour, am, and 13
		u8_alarmhour = 0b01000001;			//set hours = 24 hour, am, and 1
	}
	DELAY_MS(200) 							//Delay 1/10 second
	WriteAlarm1Time(u8_alarmdate, u8_alarmhour, u8_alarmmin);
	WriteAlarm2Time(u8_alarmdate, u8_alarmhour, u8_alarmmin);
}

void SnoozeAlarm(){
	uint8 u8_snoozedate = 0b10000001;
	uint8 u8_snoozehour = ReadHour();
	uint8 u8_snoozemin = ReadMin();
	u8_snoozemin = u8_snoozemin + 1;
	uint8 minute = u8_snoozemin;
	minute = (minute & 0b00001010);
	if(minute == 0b00001010){u8_snoozemin = u8_snoozemin + 6;}
	if(u8_snoozemin == 0b01100000){								//if mins = 60
		u8_snoozehour++;										//inc hours
		if(u8_snoozehour == 0b01110010){						//if hours = 24 hour, pm, and 12
			u8_snoozehour = 0b01010010;							//set hours = 24 hour, am, and 12
		}else if(u8_snoozehour == 0b01010010){					//if hours = 24 hour, am, and 12
			u8_snoozehour = 0b01110010;							//set hours = 24 hour, pm, and 12
		}
		if(u8_snoozehour == 0b01101010 || u8_snoozehour == 0b01001010){
			u8_snoozehour = u8_snoozehour + 6;
		}
		if(u8_snoozehour == 0b01110011){						//if hours = 24 hour, pm, and 13
			u8_snoozehour = 0b01100001;							//set hours = 24 hour, pm, and 1
		}else if(u8_snoozehour == 0b01010011){					//if hours = 24 hour, am, and 13
			u8_snoozehour = 0b01000001;							//set hours = 24 hour, am, and 1
		}
		u8_snoozemin = 0b00000000;
	}
	DELAY_MS(200) 												//Delay 1/10 second
	WriteAlarm2Time(u8_snoozedate, u8_snoozehour, u8_snoozemin);
}