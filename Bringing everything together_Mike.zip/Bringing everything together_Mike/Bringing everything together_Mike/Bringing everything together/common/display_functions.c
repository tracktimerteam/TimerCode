/*******************************************
 * Written by the "Music Alarm Clock" team *
 *******************************************/

#include "pic24_all.h"
#include "display_functions.h"
#include "clock_functions.h"
#include "pic24_i2c.h"

uint8 digit0 = 0, digit1 = 0, digit2 = 0, digit3 = 0;
uint8 AMPMSegment = 0, Colon = 1, AlarmSetSegment = 0, AlarmSegment = 0, Segments = 0;
uint8 hour = 0, hour_temp = 0, AM_PM = 0, min = 0, sec = 0, statusreg = 0;
char temp = 0;

void CONFIG_DISPLAY(uint8 u8_config){
	if(u8_config == 0){
		write2I2C1(MAX6958ADDR, Decode_Addr, 0x0E);		//Decode Mode - Hexadecimal decode for digits 1,2 and 3
	}else if(u8_config == 1){
		write2I2C1(MAX6958ADDR, Decode_Addr, 0x0F);		//Decode Mode - Hexadecimal decode for digits 3�0
	}
	write2I2C1(MAX6958ADDR, Test_Addr, 0x00);		//Test Display Off
	write2I2C1(MAX6958ADDR, Inten_Addr, 0x3F);		//Intensity - Max Intensity
	write2I2C1(MAX6958ADDR, Scan_Addr, 0x03);		//Scan limit - Displays Digits 0-3 and Segments 0-7
	write2I2C1(MAX6958ADDR, Config_Addr, 0x23);		//Configuration - Normal Operation, MAX6959, and Clears Digits
	write2I2C1(MAX6958ADDR, GPIO_Addr, 0x80);		//Sets Seg9 as a Segment Driver
	//write2I2C1(MAX6958ADDR, Test_Addr, 0x01);		//Test Display On
	write2I2C1(MAX6958ADDR, Digit0_Addr, 0x7E);
}

void WriteDigits(uint8 u8_digit0,uint8 u8_digit1,uint8 u8_digit2,uint8 u8_digit3, uint8 u8_segments){
	write2I2C1(MAX6958ADDR, Digit0_Addr, u8_digit0);
	write2I2C1(MAX6958ADDR, Digit1_Addr, u8_digit1);
	write2I2C1(MAX6958ADDR, Digit2_Addr, u8_digit2);
	write2I2C1(MAX6958ADDR, Digit3_Addr, u8_digit3);
	write2I2C1(MAX6958ADDR, Segments_Addr, u8_segments);
}

void Display(void){
	hour_temp = ReadHour();
	hour=(hour_temp & 0b00011111);		// ANDs hour to get rid of the first 3 setup bits of the hour register
	AM_PM=(hour_temp & 0b00100000);		// AM or PM is the 3rd bit in hour register

	if(AM_PM == 0b00000000){temp = 'A';	AMPMSegment = 0b00001000;}
	if(AM_PM == 0b00100000){temp = 'P';	AMPMSegment = 0b00000100;}

	//if(Colon == 0b00000001){Colon = 0b00000000;}
	//else if(Colon == 0b00000000){Colon = 0b00000001;}
	Colon = 0b00000001;

	if(OnOff_Switch == 0){AlarmSetSegment = 0b00000010;}
	else if(OnOff_Switch == 1){AlarmSetSegment = 0b00000000;}

	statusreg = ReadStatusReg();

	if((statusreg & 0b00000010) == 0b00000010){AlarmSegment = 0b00010000;}
	else if((statusreg & 0b00000010) == 0b00000000){AlarmSegment = 0b00000000;}

	min = ReadMin();
	sec = ReadSec();
	ComputerDisplay();
	digit0 = hour / 0x10;

	if(digit0 == 0x0){digit1 = hour;}
	else if(digit0 == 0x1){digit1 = hour - 0x10;}

	digit2 = min / 0x10;

	if(digit2 == 0x0){digit3 = min;}
	else{digit3 = min - (digit2 * 0x10);}

	Segments = (AMPMSegment | Colon | AlarmSetSegment | AlarmSegment);
	WriteDigits(digit0, digit1, digit2, digit3, Segments);
}

void Alarm2Display(void){
	hour_temp = ReadAlarm2Hour();
	hour=(hour_temp & 0b00011111);		// ANDs hour to get rid of the first 3 setup bits of the hour register
	AM_PM=(hour_temp & 0b00100000);		// AM or PM is the 3rd bit in hour register

	if(AM_PM == 0b00000000){temp = 'A'; AMPMSegment = 0b00001000;}
	if(AM_PM == 0b00100000){temp = 'P';	AMPMSegment = 0b00000100;}

	if(OnOff_Switch == 0){AlarmSetSegment = 0b00000010;}
	else if(OnOff_Switch == 1){AlarmSetSegment = 0b00000000;}

	Colon = 0b00000001;

	min = ReadAlarm2Min();
	ComputerAlarmDisplay();
	digit0 = hour / 0x10;

	if(digit0 == 0x0){digit1 = hour;}
	else if(digit0 == 0x1){digit1 = hour - 0x10;}

	digit2 = min / 0x10;

	if(digit2 == 0x0){digit3 = min;}
	else{digit3 = min - (digit2 * 0x10);}

	Segments = (AMPMSegment | Colon | AlarmSetSegment);
	WriteDigits(digit0, digit1, digit2, digit3, Segments);
}

void BS_Display(uint8 u8_bsflag, uint8 u8_count){
	u8_count = 10 - u8_count;

	write2I2C1(MAX6958ADDR, Digit0_Addr, 0x0E);
	write2I2C1(MAX6958ADDR, Digit1_Addr, u8_bsflag);
	write2I2C1(MAX6958ADDR, Digit2_Addr, 0x0C);
	write2I2C1(MAX6958ADDR, Digit3_Addr, u8_count);	
}