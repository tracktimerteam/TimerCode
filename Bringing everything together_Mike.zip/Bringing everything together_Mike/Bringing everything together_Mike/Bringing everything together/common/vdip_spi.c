//#include <system.h>
#include "pic24_all.h"
#include "pic24_ports.h"
#include "vdip_spi.h"

//***************************************************************************
//  
//  Pin definitions for SPI
//  
//***************************************************************************

// NOTE: pin names are relative to the VMusic device

#define PORT_SDI  _LATB2		// SDI (on VDIP1) is RB2 
//#define PORT_SDI  _RB2

#define PORT_SDO  _RB3		// SDO (on VDIP1) is RB3 
//#define TRIS_SDO  _TRISB7;

#define PORT_SCLK _LATB1		// SCLK is RB1
//#define TRIS_SCLK _TRISB5;

#define PORT_CS   _LATB4		// CS is RB4 
//#define TRIS_CS   _TRISB2;



//***************************************************************************
//  
//  Constants and variables for SPI
//  
//***************************************************************************

#define DIR_SPIWRITE 0
#define DIR_SPIREAD  1

//***************************************************************************
//
// Internal Routines
//
//***************************************************************************

int spiXfer(int spiDirection, char *pSpiData);

//***************************************************************************
// Name: spiDelay
//
// Description: Short delay.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: Uses a nop to create a very short delay.
//
//***************************************************************************
//#define spiDelay 

#define spiDelay() \
 asm("nop");\
 asm("nop");


#if 0
void spiDelay(){
		asm("nop");
		//DELAY_US(1);
}
#endif

int spiXfer(int spiDirection, char *pSpiData)
{
	unsigned char retData;
	unsigned char bitData;
	//retData=0;
	//bitData=0;
	
	// CS goes high to enable SPI communications
	//_RB2=1;
	//PORT_CS = 1;

	// Clock 1 - Start State
	PORT_SDI = 1;
	PORT_CS = 1;	

	spiDelay();
	PORT_SCLK = 1;
	spiDelay();
	PORT_SCLK = 0;

	// Clock 2 - Direction
	PORT_SDI = spiDirection;

	spiDelay();
	PORT_SCLK = 1;
	spiDelay();
	PORT_SCLK = 0;

	// Clock 3 - Address
	PORT_SDI = 0;
	
	spiDelay();				
    PORT_SCLK = 1;
	spiDelay();	
	PORT_SCLK = 0;

	//spiDelay();
	//PORT_SCLK = 1;
	//spiDelay();
	//PORT_SCLK = 0;

//	_LATA0 = 1;
	// Clocks 4..11 - Data Phase
	bitData = 0x80;
	if (spiDirection)
	{
		// read operation
		retData = 0;
		//_LATA0 = 1;			//used for testing		
		//while (bitData)
		//{
			spiDelay();
			retData |= PORT_SDO?0x80:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			spiDelay();
			retData |= PORT_SDO?0x40:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			spiDelay();
			retData |= PORT_SDO?0x20:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			spiDelay();
			retData |= PORT_SDO?0x10:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			//_LATA0 = 0;

			spiDelay();
			retData |= PORT_SDO?0x08:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			spiDelay();
			retData |= PORT_SDO?0x04:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			spiDelay();
			retData |= PORT_SDO?0x02:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;

			spiDelay();
			retData |= PORT_SDO?0x01:0;
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;
	
			//_LATA0 = 0;			//testing

		//}

		*pSpiData = retData;
	}
	else
	{
		// write operation
		retData = *pSpiData;
		
		//printf("retData = %c",retData);

		while (bitData)
			{
			PORT_SDI = (retData & bitData)?1:0;
			/*int a = PORT_SDI;
			printf("\nPort_SDI: %d",a);
			int b = PORT_SDO;
			printf("\nPort_SDO after write: %d",b);*/
			spiDelay();
			PORT_SCLK = 1;
			spiDelay();
			PORT_SCLK = 0;
			bitData = bitData >> 1;
		}
	}
	//_LATA0 =0;
	//printf("Data Xfer'd");
	// Clock 12 - Status bit
	//bitData = PORT_SDO;		//TRY THIS!!!
	spiDelay();
	bitData = PORT_SDO;			//0 = new data read/data recieved		
								//1 = old data read/data not received
	/*if(bitData == 1){
		_LATA1 = 1;
		DELAY_US(10);			//testing
		_LATA1 = 0;
	}*/

	PORT_SCLK = 1;
	spiDelay();	
	//bitData = PORT_SDO;		//TRY THIS!!!!
	PORT_SCLK = 0;

	// CS goes low to disable SPI communications
	PORT_CS = 0;
	spiDelay();

	// Clock 13 - CS low
	spiDelay();
	PORT_SCLK = 1;
	spiDelay();
	PORT_SCLK = 0;

//	spiDelay();
//	PORT_SCLK = 1;
//	spiDelay();
//	PORT_SCLK = 0;

	//printf("Clock 13");
	//printf("bitData = %X \n",bitData);
	
    return bitData;

}

//***************************************************************************
//
// External Routines
//
//***************************************************************************

//***************************************************************************
// Name: spiInit
//
// Description: Initialise the SPI interface. 
//
// Parameters: None.
//
// Returns: None.
//
// Comments: Sets up pins connecting to the SPI interface.
//
//***************************************************************************
void spiInit()
{
	
//	TRIS_SDO = 1;			        // SDO input 			
//	TRIS_SDI = 0;					// SDI output
//	TRIS_SCLK = 0;				// SCLK output
//	TRIS_CS = 0;				// CS output

// Configure pin direction (1 for input, 0 for output)
	//_TRISB7 = 1;	//SD0 input (SDI on PIC)
	CONFIG_RB1_AS_DIG_OUTPUT();
	CONFIG_RB2_AS_DIG_OUTPUT();
	CONFIG_RB3_AS_DIG_INPUT();
	//_TRISB6 = 0;	//SDI output (SD0 on PIC)
	//_TRISB5 = 0;	//SCLK output
	//_TRISB2 = 0;	//CS output
	CONFIG_RB4_AS_DIG_OUTPUT();
	
	// Configure initial pin states

	// SDO starts low
	PORT_SDI = 0;
	// SCLK starts low
	PORT_SCLK = 0;
	// CS starts low
	PORT_CS = 0;
}
//***************************************************************************
// Name: spiReadWait
//
// Description: Blocking read of character from SPI bus. 
//
// Parameters: None.
//
// Returns: spiData - Byte received.
//
// Comments: Waits until a character is read from the SPI bus and returns.
//
//***************************************************************************
char spiReadWait()
{
	char spiData;

	while (spiXfer(DIR_SPIREAD, &spiData));
	//printf("%c",spiData);

	return spiData;
}
//***************************************************************************
// Name: spiRead
//
// Description: Non-blocking read of character from SPI bus. 
//
// Parameters: None.
//
// Returns: pSpiData - Byte received.
//          int XFER_OK if data received, XFER_RETRY if not.
//
// Comments: Check for a character on the SPI bus and return.
//
//***************************************************************************
int spiRead(char *pSpiData)
{
	return spiXfer(DIR_SPIREAD, pSpiData);
}

//***************************************************************************
// Name: spiWrite
//
// Description: Blocking write of character to SPI bus. 
//
// Parameters: spiData - Byte to be transmitted.
//
// Returns: None.
//
// Comments: Waits until a character is transmitted on the SPI bus.
//
//***************************************************************************
void spiWrite(char spiData)
{
	while(spiXfer(DIR_SPIWRITE, &spiData));
	//spiXfer(DIR_SPIWRITE, &spiData);
}


