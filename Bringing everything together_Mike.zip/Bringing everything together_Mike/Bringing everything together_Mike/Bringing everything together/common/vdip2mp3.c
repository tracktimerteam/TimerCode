#include "pic24_all.h"
#include "vdip_spi.h"
#include "vdip_func.h"
#include "mp3_spi.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ALARM_SIG	_RF1
#define mp3_buf	  1024			//1465

volatile uint8 mp3_data[mp3_buf];
volatile int head,tail,newtail;


void _ISR _T3Interrupt (void) {
	if(DREQ){
		if(head!=tail){
			SLAVE_DISABLE();
			ioMasterSPI2(mp3_data[head]);
			SLAVE_ENABLE();
			head++;
	
			if(head==mp3_buf){
				head=0;	
			}
		}
  	}
	_T3IF = 0;
}

#define ISR_PERIOD     3 	//5	//7                // in microseconds

void  configTimer3(void) {
  //ensure that Timer2,3 configured as separate timers.
  T2CONbits.T32 = 0;     // 32-bit mode off
  //T3CON set like this for documentation purposes.
  //could be replaced by T3CON = 0x0020
  T3CON = T3_OFF |T3_IDLE_CON | T3_GATE_OFF
          | T3_SOURCE_INT
          | T3_PS_1_1 ;
  PR3 = usToU16Ticks (ISR_PERIOD, getTimerPrescale(T3CONbits)) - 1;
  TMR3  = 0;                       //clear timer3 value
  _T3IF = 0;                       //clear interrupt flag
  _T3IP = 1;                       //choose a priority
  _T3IE = 0;                       //does not enable the interrupt
  T3CONbits.TON = 1;               //turn on the timer
}

int main (void){
	uint8 usb_status;
	int j,newtail;

	configBasic(HELLO_MSG);
	configSPI2();							//configs SPI port for MP3 decoder

	//CONFIG_RA2_AS_DIG_OUTPUT();				//usb status LED
	//_LATA2 = 0;
	usb_status = 0;

	CONFIG_RF1_AS_DIG_INPUT();				//Alarm signal	
			
	srand( (unsigned int)time( NULL ) );	//start RNG
		
	spiInit();								//config SPI for VDIP1
				
	VDIP_Reset();				
	VDIP_Sync();						//syncs VDIP with PIC
	VDIP_SCS();							//put VDIP in short command set


	while(usb_status == 0){				//check for disk
		while(VDIP_CheckDisk()==0);
		usb_status = 1;
	}
	
	while(VDIP_ListFiles() == 0);		//check for mp3 file
	
	//printf("VDIP Done \n");
	MP3_Config();
	printf("MP3 Config Done \n");
	configTimer3();
	printf("Timer Config Done \n");

	while(1){
   		if(!ALARM_SIG){
			VDIP_Reset();
			VDIP_Sync();	
			VDIP_SCS();	
			VDIP_ReadRand();				//read random mp3
			//VDIP_ReadRand();
	
			//int j, newtail;
 			head = 0;
			tail = head;

			for(j=0;j<=mp3_buf;j++){				//initialize mp3_data buffer
				mp3_data[mp3_buf] = 0;
			}

			for(tail=0;tail<mp3_buf-10;tail++){		//fill mp3_data buffer		
				mp3_data[tail]=spiReadWait();
			}


			_T3IE = 1;								//enable interrupt to send mp3 data every 10us

			while(!ALARM_SIG){						//keep mp3_data buffer full
				newtail = tail;
				newtail++;
			
				while(newtail == head);
	
				mp3_data[tail]= spiReadWait();
				tail++;
				if(tail==mp3_buf){
					tail = 0;
				}
	 		}
		}
		else{
			_T3IE = 0;
		}
  	}
 }



